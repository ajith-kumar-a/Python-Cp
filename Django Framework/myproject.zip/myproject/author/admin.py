from django.contrib import admin
from .models import author

# Register your models here.
admin.site.register(author)