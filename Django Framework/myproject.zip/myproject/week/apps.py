from django.apps import AppConfig


class WeekConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'week'
